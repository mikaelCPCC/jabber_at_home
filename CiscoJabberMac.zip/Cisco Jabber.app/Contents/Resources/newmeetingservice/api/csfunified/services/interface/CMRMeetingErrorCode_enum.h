/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef CMRMEETINGERRORCODE_ENUM_H
#define CMRMEETINGERRORCODE_ENUM_H


namespace CSFUnified
{
    namespace CMRMeetingErrorCodeEnum
    {
        enum CMRMeetingErrorCode {
        CMR_SUCCESS = 0,
        CMR_FAILED_NOT_SUPPORT = 1,
        CMR_FAILED_COMMON_ERROR = 1000 
        };
    }
}
#endif