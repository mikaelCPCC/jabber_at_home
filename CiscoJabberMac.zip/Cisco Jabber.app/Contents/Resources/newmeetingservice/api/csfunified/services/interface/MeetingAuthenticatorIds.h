/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGAUTHENTICATORIDS_H
#define MEETINGAUTHENTICATORIDS_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "MeetingAuthenticatorIds_enum.h"

namespace CSFUnified
{
    namespace MeetingAuthenticatorIdsEnum
    {

       
        #ifndef SWIG
        inline std::string toString(MeetingAuthenticatorIds value)
        {
            switch(value)
            {
                case MeetingAuthenticator:
                    return "MeetingAuthenticator";
                case CustomizedMeetingAuthenticator:
                    return "CustomizedMeetingAuthenticator";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(MeetingAuthenticatorIds value)
        {
            switch(value)
            {
                case MeetingAuthenticator:
                    return L"MeetingAuthenticator";
                case CustomizedMeetingAuthenticator:
                    return L"CustomizedMeetingAuthenticator";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<MeetingAuthenticatorIds> MeetingAuthenticatorIdsEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<MeetingAuthenticatorIds> > MeetingAuthenticatorIdsEnumeratorPtr;
		
		inline MeetingAuthenticatorIdsEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<MeetingAuthenticatorIds> > vec( new std::vector<MeetingAuthenticatorIds>());
			
			if (vec->empty())
			{
                vec->push_back( MeetingAuthenticator );
                vec->push_back( CustomizedMeetingAuthenticator );
            }
			
			return vec;
        }
		#endif
    }
}
#endif