/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGACCOUNTCONTROLLER_H
#define MEETINGACCOUNTCONTROLLER_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedBusinessObject.h"
#include "csf/security/SecureString.hpp"

namespace CSFUnified
{
    class MeetingAccountCallback;
    class MeetingSite;

/**
    @class MeetingAccountControllerObserver
    This interface when implemented allows you to act as an observer for the MeetingAccountController class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API MeetingAccountControllerObserver : virtual public UnifiedBusinessObjectObserver
    {
        public:
        

        

/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingAccountControllerObserver";
        }

    };
/**
    @class MeetingAccountControllerNotifiers
    This class gives you access to a single notifer object for each property on the MeetingAccountController class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the MeetingAccountControllerObserver class
*/

    class CSFUNIFIED_API MeetingAccountControllerNotifiers : virtual public UnifiedBusinessObjectNotifiers
    {
        public:

        

        
    };
    

	class CSFUNIFIED_API MeetingAccountController : virtual public UnifiedBusinessObject
    {
        public:

        


        using UnifiedBusinessObject::addObserver;
        using UnifiedBusinessObject::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<MeetingAccountControllerObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<MeetingAccountControllerObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<MeetingAccountControllerNotifiers> getMeetingAccountControllerNotifiers() = 0;

        

        
    
        virtual void registerMeetingAccountCallback(SMART_PTR_NS::shared_ptr<MeetingAccountCallback> meetingAccountCallback) = 0;
        virtual void unregisterMeetingAccountCallback(SMART_PTR_NS::shared_ptr<MeetingAccountCallback> meetingAccountCallback) = 0;
        virtual bool isReady() = 0;
        virtual bool isActive() = 0;
        virtual int getMeetingSiteCount() = 0;
        virtual SMART_PTR_NS::shared_ptr<MeetingSite> getMeetingSiteByIndex(int index) = 0;
        virtual SMART_PTR_NS::shared_ptr<MeetingSite> getDefaultMeetingSite() = 0;
        virtual void checkSSOSite(std::string siteUrl) = 0;
        virtual int isSSOSite(std::string siteUrl) = 0;
        virtual void setActiveSite(std::string siteUrl, std::string userName, const csf::SecureString& userPass) = 0;
        virtual void setActiveSite(std::string siteUrl, std::string userName, std::string sessionTicket, long keepAliveTime) = 0;
        virtual void removeSite(std::string siteUrl) = 0;
        virtual int getSiteLastError() = 0;
        virtual std::string getSiteLastErrorMessage() = 0;



/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingAccountController";
        }

    };
    
}

#endif