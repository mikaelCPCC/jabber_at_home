/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/

#ifndef DSCALLBACK_H
#define DSCALLBACK_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedCallback.h"

namespace CSFUnified 
{


    class CSFUNIFIED_API DSCallback : public UnifiedCallback
    {
        public:

        

        
    
        virtual void onDSStarted(std::string sessionName) = 0;
        virtual void onDSDeclined(std::string sessionName) = 0;
        virtual void onDSCancelled(std::string sessionName) = 0;
        virtual void onDSEnded(std::string sessionName) = 0;
        virtual void onDSError(std::string sessionName, int errCode) = 0;
        virtual void onDSInvitationReceived(std::string sessionName) = 0;
        virtual void onDSInvitationCanceled(std::string sessionName) = 0;
        virtual void onUserJoined() = 0;
        virtual void onUserTryLeave(bool host) = 0;
        virtual void onUserLeft() = 0;
        virtual void onShowStartingDialog(bool show) = 0;
        virtual void onRequestMinimizeWindow() = 0;
        virtual void onRequestRestoreWindow() = 0;
        virtual void onNotifyUIUpdate() = 0;
        virtual void onPresenterChanged() = 0;
        virtual void onSharingStopped(std::string sessionName) = 0;
        virtual void onCleanUp() = 0;
        virtual void onCleanSession(std::string sessionName) = 0;
        virtual void onErrorMsg(std::string sessionName, int eType) = 0;



        /**    
	 Gives the name of this business object for logging and wrapping purposes    
		*/
        virtual std::string getInterfaceName()
        {
            return "DSCallback";
        }
    };

}

#endif