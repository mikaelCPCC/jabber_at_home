/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGREMINDERTYPE_H
#define MEETINGREMINDERTYPE_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "MeetingReminderType_enum.h"

namespace CSFUnified
{
    namespace MeetingReminderTypeEnum
    {

       
        #ifndef SWIG
        inline std::string toString(MeetingReminderType value)
        {
            switch(value)
            {
                case WRT_SELF_AUTO_REMIND:
                    return "WRT_SELF_AUTO_REMIND";
                case WRT_HOST_AUTO_REMIND:
                    return "WRT_HOST_AUTO_REMIND";
                case WRT_ATTENDEE_MANUAL_REMIND:
                    return "WRT_ATTENDEE_MANUAL_REMIND";
                case WRT_ATTENDEE_MANUAL_INVITE:
                    return "WRT_ATTENDEE_MANUAL_INVITE";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(MeetingReminderType value)
        {
            switch(value)
            {
                case WRT_SELF_AUTO_REMIND:
                    return L"WRT_SELF_AUTO_REMIND";
                case WRT_HOST_AUTO_REMIND:
                    return L"WRT_HOST_AUTO_REMIND";
                case WRT_ATTENDEE_MANUAL_REMIND:
                    return L"WRT_ATTENDEE_MANUAL_REMIND";
                case WRT_ATTENDEE_MANUAL_INVITE:
                    return L"WRT_ATTENDEE_MANUAL_INVITE";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<MeetingReminderType> MeetingReminderTypeEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<MeetingReminderType> > MeetingReminderTypeEnumeratorPtr;
		
		inline MeetingReminderTypeEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<MeetingReminderType> > vec( new std::vector<MeetingReminderType>());
			
			if (vec->empty())
			{
                vec->push_back( WRT_SELF_AUTO_REMIND );
                vec->push_back( WRT_HOST_AUTO_REMIND );
                vec->push_back( WRT_ATTENDEE_MANUAL_REMIND );
                vec->push_back( WRT_ATTENDEE_MANUAL_INVITE );
            }
			
			return vec;
        }
		#endif
    }
}
#endif