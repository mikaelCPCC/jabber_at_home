/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGERRORCODE_H
#define MEETINGERRORCODE_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "MeetingErrorCode_enum.h"

namespace CSFUnified
{
    namespace MeetingErrorCodeEnum
    {

       
        #ifndef SWIG
        inline std::string toString(MeetingErrorCode value)
        {
            switch(value)
            {
                case MEETING_SUCCESS:
                    return "MEETING_SUCCESS";
                case MEETING_FAILED_FUNCOFF:
                    return "MEETING_FAILED_FUNCOFF";
                case MEETING_FAILED_INITIALIZING:
                    return "MEETING_FAILED_INITIALIZING";
                case MEETING_DATE_NOT_CHANGE:
                    return "MEETING_DATE_NOT_CHANGE";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(MeetingErrorCode value)
        {
            switch(value)
            {
                case MEETING_SUCCESS:
                    return L"MEETING_SUCCESS";
                case MEETING_FAILED_FUNCOFF:
                    return L"MEETING_FAILED_FUNCOFF";
                case MEETING_FAILED_INITIALIZING:
                    return L"MEETING_FAILED_INITIALIZING";
                case MEETING_DATE_NOT_CHANGE:
                    return L"MEETING_DATE_NOT_CHANGE";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<MeetingErrorCode> MeetingErrorCodeEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<MeetingErrorCode> > MeetingErrorCodeEnumeratorPtr;
		
		inline MeetingErrorCodeEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<MeetingErrorCode> > vec( new std::vector<MeetingErrorCode>());
			
			if (vec->empty())
			{
                vec->push_back( MEETING_SUCCESS );
                vec->push_back( MEETING_FAILED_FUNCOFF );
                vec->push_back( MEETING_FAILED_INITIALIZING );
                vec->push_back( MEETING_DATE_NOT_CHANGE );
            }
			
			return vec;
        }
		#endif
    }
}
#endif