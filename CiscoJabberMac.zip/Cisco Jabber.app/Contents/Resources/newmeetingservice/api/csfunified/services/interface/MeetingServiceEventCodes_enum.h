/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGSERVICEEVENTCODES_ENUM_H
#define MEETINGSERVICEEVENTCODES_ENUM_H


namespace CSFUnified
{
    namespace MeetingServiceEventCodesEnum
    {
        enum MeetingServiceEventCodes {
        Invalid_CA = 1 
        };
    }
}
#endif