/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGSERVICEFEATURESETTYPES_H
#define MEETINGSERVICEFEATURESETTYPES_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "MeetingServiceFeatureSetTypes_enum.h"

namespace CSFUnified
{
    namespace MeetingServiceFeatureSetTypesEnum
    {

       
        #ifndef SWIG
        inline std::string toString(MeetingServiceFeatureSetTypes value)
        {
            switch(value)
            {
                case Meeting:
                    return "Meeting";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(MeetingServiceFeatureSetTypes value)
        {
            switch(value)
            {
                case Meeting:
                    return L"Meeting";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<MeetingServiceFeatureSetTypes> MeetingServiceFeatureSetTypesEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<MeetingServiceFeatureSetTypes> > MeetingServiceFeatureSetTypesEnumeratorPtr;
		
		inline MeetingServiceFeatureSetTypesEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<MeetingServiceFeatureSetTypes> > vec( new std::vector<MeetingServiceFeatureSetTypes>());
			
			if (vec->empty())
			{
                vec->push_back( Meeting );
            }
			
			return vec;
        }
		#endif
    }
}
#endif