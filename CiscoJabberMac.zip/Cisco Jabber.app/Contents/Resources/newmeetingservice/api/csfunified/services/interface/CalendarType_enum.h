/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef CALENDARTYPE_ENUM_H
#define CALENDARTYPE_ENUM_H


namespace CSFUnified
{
    namespace CalendarTypeEnum
    {
        enum CalendarType {
        CALENDAR_NONE = 0,
        CALENDAR_OUTLOOK = 1,
        CALENDAR_LOTUS = 2,
        CALENDAR_GOOGLE = 3 
        };
    }
}
#endif