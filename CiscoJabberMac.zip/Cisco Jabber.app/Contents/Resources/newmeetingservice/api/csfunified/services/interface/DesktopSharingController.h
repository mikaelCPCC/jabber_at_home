/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef DESKTOPSHARINGCONTROLLER_H
#define DESKTOPSHARINGCONTROLLER_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedBusinessObject.h"

namespace CSFUnified
{
    class DSCallback;

/**
    @class DesktopSharingControllerObserver
    This interface when implemented allows you to act as an observer for the DesktopSharingController class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API DesktopSharingControllerObserver : virtual public UnifiedBusinessObjectObserver
    {
        public:
        

        

/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "DesktopSharingControllerObserver";
        }

    };
/**
    @class DesktopSharingControllerNotifiers
    This class gives you access to a single notifer object for each property on the DesktopSharingController class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the DesktopSharingControllerObserver class
*/

    class CSFUNIFIED_API DesktopSharingControllerNotifiers : virtual public UnifiedBusinessObjectNotifiers
    {
        public:

        

        
    };
    

	class CSFUNIFIED_API DesktopSharingController : virtual public UnifiedBusinessObject
    {
        public:

        


        using UnifiedBusinessObject::addObserver;
        using UnifiedBusinessObject::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<DesktopSharingControllerObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<DesktopSharingControllerObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<DesktopSharingControllerNotifiers> getDesktopSharingControllerNotifiers() = 0;

        

        
    
        virtual void registerDSCallback(SMART_PTR_NS::shared_ptr<DSCallback> dsCallback) = 0;
        virtual void unregisterDSCallback(SMART_PTR_NS::shared_ptr<DSCallback> dsCallback) = 0;
        virtual bool isInSharing() = 0;
        virtual bool canStartSharing(std::string sessionName) = 0;
        virtual bool startSharing(std::string sessionName) = 0;
        virtual bool canJoinSharing(std::string sessionName) = 0;
        virtual bool joinSharing(std::string sessionName) = 0;
        virtual bool stopSharing() = 0;
        virtual bool reInviteCurSession() = 0;
        virtual bool restartSharing() = 0;
        virtual bool changePresenter() = 0;
        virtual bool cancelSharing() = 0;
        virtual bool declineSharing(std::string sessionName) = 0;



/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "DesktopSharingController";
        }

    };
    
}

#endif