/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/

#ifndef MEETINGCALLBACK_H
#define MEETINGCALLBACK_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedCallback.h"
#include "csfunified/services/interface/MeetingErrorCode.h"

namespace CSFUnified 
{

    class MeetingTime;
    class MeetingInfo;
    class MeetingReminderInfo;
    class MeetingIMAlertItemObject;

    class CSFUNIFIED_API MeetingCallback : public UnifiedCallback
    {
        public:

        

        
    
        virtual void onCalendarEnabled(bool bEnabled) = 0;
        virtual void onMeetingEnabled(bool bEnabled) = 0;
        virtual void onMeetingListed(SMART_PTR_NS::shared_ptr<MeetingTime> meetingDay, SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingInfo> > > meetingList, MeetingErrorCodeEnum::MeetingErrorCode errCode) = 0;
        virtual void onMeetingOvernight() = 0;
        virtual void onGetMeetingDetail(SMART_PTR_NS::shared_ptr<MeetingInfo> meeting) = 0;
        virtual void onGetCMRInfo(std::string cmrInfo) = 0;
        virtual void onInitializeOIFailed() = 0;
        virtual void onInitializeResult(long lResult) = 0;
        virtual void onMeetingStart(std::string meetingID, std::string meetingKey) = 0;
        virtual void onMeetingEnd(std::string meetingID, std::string meetingKey) = 0;
        virtual void onMeetingStarted(std::string sessionName, std::string meetingID, bool host) = 0;
        virtual void onMeetingDeclined(std::string sessionName, std::string attendeeName) = 0;
        virtual void onMeetingEnded(std::string sessionName, std::string meetingID, bool host) = 0;
        virtual void onMeetingError(std::string sessionName, int errCode) = 0;
        virtual void onMeetingInvitationReceived(std::string sessionName, std::string meetingTopic) = 0;
        virtual void onMeetingInvitationCanceled(std::string sessionName) = 0;
        virtual void onMeetingReminderHappened(SMART_PTR_NS::shared_ptr<MeetingReminderInfo> meetingReminder) = 0;
        virtual void onMeetingReminderUpdated(SMART_PTR_NS::shared_ptr<MeetingReminderInfo> meetingReminder) = 0;
        virtual void onMeetingIMAlertHappened(SMART_PTR_NS::shared_ptr<MeetingIMAlertItemObject> objItem) = 0;
        virtual void onMeetingReminderEnded(std::string meetingID) = 0;
        virtual void onShowMeetingWaitDialog() = 0;
        virtual void onHideMeetingWaitDialog() = 0;
        virtual void onShowMeetingErrorDialog(int errCode) = 0;
        virtual void onNetworkConnect() = 0;
        virtual void onNetworkDisconnect() = 0;



        /**    
	 Gives the name of this business object for logging and wrapping purposes    
		*/
        virtual std::string getInterfaceName()
        {
            return "MeetingCallback";
        }
    };

}

#endif