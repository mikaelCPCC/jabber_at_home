/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGSERVICEEVENTCODES_H
#define MEETINGSERVICEEVENTCODES_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "MeetingServiceEventCodes_enum.h"

namespace CSFUnified
{
    namespace MeetingServiceEventCodesEnum
    {

       
        #ifndef SWIG
        inline std::string toString(MeetingServiceEventCodes value)
        {
            switch(value)
            {
                case Invalid_CA:
                    return "Invalid_CA";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(MeetingServiceEventCodes value)
        {
            switch(value)
            {
                case Invalid_CA:
                    return L"Invalid_CA";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<MeetingServiceEventCodes> MeetingServiceEventCodesEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<MeetingServiceEventCodes> > MeetingServiceEventCodesEnumeratorPtr;
		
		inline MeetingServiceEventCodesEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<MeetingServiceEventCodes> > vec( new std::vector<MeetingServiceEventCodes>());
			
			if (vec->empty())
			{
                vec->push_back( Invalid_CA );
            }
			
			return vec;
        }
		#endif
    }
}
#endif