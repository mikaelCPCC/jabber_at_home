/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef CMRMEETINGERRORCODE_H
#define CMRMEETINGERRORCODE_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "CMRMeetingErrorCode_enum.h"

namespace CSFUnified
{
    namespace CMRMeetingErrorCodeEnum
    {

       
        #ifndef SWIG
        inline std::string toString(CMRMeetingErrorCode value)
        {
            switch(value)
            {
                case CMR_SUCCESS:
                    return "CMR_SUCCESS";
                case CMR_FAILED_NOT_SUPPORT:
                    return "CMR_FAILED_NOT_SUPPORT";
                case CMR_FAILED_COMMON_ERROR:
                    return "CMR_FAILED_COMMON_ERROR";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(CMRMeetingErrorCode value)
        {
            switch(value)
            {
                case CMR_SUCCESS:
                    return L"CMR_SUCCESS";
                case CMR_FAILED_NOT_SUPPORT:
                    return L"CMR_FAILED_NOT_SUPPORT";
                case CMR_FAILED_COMMON_ERROR:
                    return L"CMR_FAILED_COMMON_ERROR";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<CMRMeetingErrorCode> CMRMeetingErrorCodeEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<CMRMeetingErrorCode> > CMRMeetingErrorCodeEnumeratorPtr;
		
		inline CMRMeetingErrorCodeEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<CMRMeetingErrorCode> > vec( new std::vector<CMRMeetingErrorCode>());
			
			if (vec->empty())
			{
                vec->push_back( CMR_SUCCESS );
                vec->push_back( CMR_FAILED_NOT_SUPPORT );
                vec->push_back( CMR_FAILED_COMMON_ERROR );
            }
			
			return vec;
        }
		#endif
    }
}
#endif