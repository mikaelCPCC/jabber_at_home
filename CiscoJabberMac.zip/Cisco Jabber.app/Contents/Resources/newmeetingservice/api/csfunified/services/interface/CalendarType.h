/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef CALENDARTYPE_H
#define CALENDARTYPE_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "CalendarType_enum.h"

namespace CSFUnified
{
    namespace CalendarTypeEnum
    {

       
        #ifndef SWIG
        inline std::string toString(CalendarType value)
        {
            switch(value)
            {
                case CALENDAR_NONE:
                    return "CALENDAR_NONE";
                case CALENDAR_OUTLOOK:
                    return "CALENDAR_OUTLOOK";
                case CALENDAR_LOTUS:
                    return "CALENDAR_LOTUS";
                case CALENDAR_GOOGLE:
                    return "CALENDAR_GOOGLE";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(CalendarType value)
        {
            switch(value)
            {
                case CALENDAR_NONE:
                    return L"CALENDAR_NONE";
                case CALENDAR_OUTLOOK:
                    return L"CALENDAR_OUTLOOK";
                case CALENDAR_LOTUS:
                    return L"CALENDAR_LOTUS";
                case CALENDAR_GOOGLE:
                    return L"CALENDAR_GOOGLE";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<CalendarType> CalendarTypeEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<CalendarType> > CalendarTypeEnumeratorPtr;
		
		inline CalendarTypeEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<CalendarType> > vec( new std::vector<CalendarType>());
			
			if (vec->empty())
			{
                vec->push_back( CALENDAR_NONE );
                vec->push_back( CALENDAR_OUTLOOK );
                vec->push_back( CALENDAR_LOTUS );
                vec->push_back( CALENDAR_GOOGLE );
            }
			
			return vec;
        }
		#endif
    }
}
#endif