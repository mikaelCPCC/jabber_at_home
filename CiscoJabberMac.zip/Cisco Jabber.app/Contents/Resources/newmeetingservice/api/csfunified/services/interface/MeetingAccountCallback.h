/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/

#ifndef MEETINGACCOUNTCALLBACK_H
#define MEETINGACCOUNTCALLBACK_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedCallback.h"

namespace CSFUnified 
{

    class MeetingSite;

    class CSFUNIFIED_API MeetingAccountCallback : public UnifiedCallback
    {
        public:

        

        
    
        virtual void onMeetingSiteActived(bool activeFlag, std::string siteUrl, SMART_PTR_NS::shared_ptr<MeetingSite> site) = 0;
        virtual void onSSOSiteChecked(std::string siteUrl, int ssoFlag) = 0;
        virtual void onMeetingSiteRemoved(std::string siteUrl) = 0;
        virtual void requireRefreshSessionTicket(std::string siteUrl, bool refresh) = 0;



        /**    
	 Gives the name of this business object for logging and wrapping purposes    
		*/
        virtual std::string getInterfaceName()
        {
            return "MeetingAccountCallback";
        }
    };

}

#endif