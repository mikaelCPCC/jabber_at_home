/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MAILSERVICETYPE_H
#define MAILSERVICETYPE_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "MailServiceType_enum.h"

namespace CSFUnified
{
    namespace MailServiceTypeEnum
    {

       
        #ifndef SWIG
        inline std::string toString(MailServiceType value)
        {
            switch(value)
            {
                case NONE:
                    return "NONE";
                case OUTLOOK:
                    return "OUTLOOK";
                case LOTUS:
                    return "LOTUS";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(MailServiceType value)
        {
            switch(value)
            {
                case NONE:
                    return L"NONE";
                case OUTLOOK:
                    return L"OUTLOOK";
                case LOTUS:
                    return L"LOTUS";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<MailServiceType> MailServiceTypeEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<MailServiceType> > MailServiceTypeEnumeratorPtr;
		
		inline MailServiceTypeEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<MailServiceType> > vec( new std::vector<MailServiceType>());
			
			if (vec->empty())
			{
                vec->push_back( NONE );
                vec->push_back( OUTLOOK );
                vec->push_back( LOTUS );
            }
			
			return vec;
        }
		#endif
    }
}
#endif