/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGERRORCODE_ENUM_H
#define MEETINGERRORCODE_ENUM_H


namespace CSFUnified
{
    namespace MeetingErrorCodeEnum
    {
        enum MeetingErrorCode {
        MEETING_SUCCESS = 0,
        MEETING_FAILED_FUNCOFF = 1,
        MEETING_FAILED_INITIALIZING = 2,
        MEETING_DATE_NOT_CHANGE = 3 
        };
    }
}
#endif