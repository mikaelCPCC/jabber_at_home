/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGCALLINNUM_H
#define MEETINGCALLINNUM_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedBusinessObject.h"

namespace CSFUnified
{

/**
    @class MeetingCallInNumObserver
    This interface when implemented allows you to act as an observer for the MeetingCallInNum class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API MeetingCallInNumObserver : virtual public UnifiedBusinessObjectObserver
    {
        public:
        

        
    
        virtual void OnTeleLocationChanged() = 0;
        virtual void OnTollNumChanged() = 0;
        virtual void OnIsTollFreeChanged() = 0;
	


/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingCallInNumObserver";
        }

    };
/**
    @class MeetingCallInNumNotifiers
    This class gives you access to a single notifer object for each property on the MeetingCallInNum class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the MeetingCallInNumObserver class
*/

    class CSFUNIFIED_API MeetingCallInNumNotifiers : virtual public UnifiedBusinessObjectNotifiers
    {
        public:

        

         
    
    /**    
        Returns the notifier for the TeleLocation property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getTeleLocationNotifier() =0;
    /**    
        Returns the notifier for the TollNum property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getTollNumNotifier() =0;
    /**    
        Returns the notifier for the IsTollFree property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getIsTollFreeNotifier() =0;
	

    };
    

	class CSFUNIFIED_API MeetingCallInNum : virtual public UnifiedBusinessObject
    {
        public:

        


        using UnifiedBusinessObject::addObserver;
        using UnifiedBusinessObject::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<MeetingCallInNumObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<MeetingCallInNumObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<MeetingCallInNumNotifiers> getMeetingCallInNumNotifiers() = 0;

        
    
        virtual std::string getTeleLocation() = 0;
        virtual std::string getTollNum() = 0;
        virtual bool getIsTollFree() = 0;
	


        

/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingCallInNum";
        }

    };
    
}

#endif