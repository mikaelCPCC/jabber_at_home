/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MAILSERVICETYPE_ENUM_H
#define MAILSERVICETYPE_ENUM_H


namespace CSFUnified
{
    namespace MailServiceTypeEnum
    {
        enum MailServiceType {
        NONE = 0,
        OUTLOOK = 1,
        LOTUS = 2 
        };
    }
}
#endif