/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGAUTHENTICATORIDS_ENUM_H
#define MEETINGAUTHENTICATORIDS_ENUM_H


namespace CSFUnified
{
    namespace MeetingAuthenticatorIdsEnum
    {
        enum MeetingAuthenticatorIds {
        MeetingAuthenticator = 3000,
        CustomizedMeetingAuthenticator = 3001 
        };
    }
}
#endif