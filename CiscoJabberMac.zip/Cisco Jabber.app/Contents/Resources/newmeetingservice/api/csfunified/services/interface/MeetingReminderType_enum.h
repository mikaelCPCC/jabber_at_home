/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGREMINDERTYPE_ENUM_H
#define MEETINGREMINDERTYPE_ENUM_H


namespace CSFUnified
{
    namespace MeetingReminderTypeEnum
    {
        enum MeetingReminderType {
        WRT_SELF_AUTO_REMIND = 0,
        WRT_HOST_AUTO_REMIND = 1,
        WRT_ATTENDEE_MANUAL_REMIND = 2,
        WRT_ATTENDEE_MANUAL_INVITE = 3 
        };
    }
}
#endif