/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGREMINDERINFO_H
#define MEETINGREMINDERINFO_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedBusinessObject.h"
#include "csfunified/services/interface/MeetingReminderType.h"

namespace CSFUnified
{
    class MeetingTime;

/**
    @class MeetingReminderInfoObserver
    This interface when implemented allows you to act as an observer for the MeetingReminderInfo class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API MeetingReminderInfoObserver : virtual public UnifiedBusinessObjectObserver
    {
        public:
        

        
    
        virtual void OnReminderTypeChanged() = 0;
        virtual void OnReminderSenderChanged() = 0;
        virtual void OnMeetingIDChanged() = 0;
        virtual void OnMeetingTopicChanged() = 0;
        virtual void OnLocationChanged() = 0;
        virtual void OnHostEmailChanged() = 0;
        virtual void OnHostDisplayNameChanged() = 0;
        virtual void OnIsHostChanged() = 0;
        virtual void OnStartTimeChanged() = 0;
        virtual void OnEndTimeChanged() = 0;
        virtual void OnDurationChanged() = 0;
        virtual void OnSiteUrlChanged() = 0;
        virtual void OnMeetingKeyChanged() = 0;
        virtual void OnJoinUrlChanged() = 0;
	


/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingReminderInfoObserver";
        }

    };
/**
    @class MeetingReminderInfoNotifiers
    This class gives you access to a single notifer object for each property on the MeetingReminderInfo class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the MeetingReminderInfoObserver class
*/

    class CSFUNIFIED_API MeetingReminderInfoNotifiers : virtual public UnifiedBusinessObjectNotifiers
    {
        public:

        

         
    
    /**    
        Returns the notifier for the ReminderType property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getReminderTypeNotifier() =0;
    /**    
        Returns the notifier for the ReminderSender property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getReminderSenderNotifier() =0;
    /**    
        Returns the notifier for the MeetingID property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingIDNotifier() =0;
    /**    
        Returns the notifier for the MeetingTopic property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingTopicNotifier() =0;
    /**    
        Returns the notifier for the Location property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getLocationNotifier() =0;
    /**    
        Returns the notifier for the HostEmail property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getHostEmailNotifier() =0;
    /**    
        Returns the notifier for the HostDisplayName property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getHostDisplayNameNotifier() =0;
    /**    
        Returns the notifier for the IsHost property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getIsHostNotifier() =0;
    /**    
        Returns the notifier for the StartTime property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getStartTimeNotifier() =0;
    /**    
        Returns the notifier for the EndTime property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getEndTimeNotifier() =0;
    /**    
        Returns the notifier for the Duration property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getDurationNotifier() =0;
    /**    
        Returns the notifier for the SiteUrl property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getSiteUrlNotifier() =0;
    /**    
        Returns the notifier for the MeetingKey property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingKeyNotifier() =0;
    /**    
        Returns the notifier for the JoinUrl property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getJoinUrlNotifier() =0;
	

    };
    

	class CSFUNIFIED_API MeetingReminderInfo : virtual public UnifiedBusinessObject
    {
        public:

        


        using UnifiedBusinessObject::addObserver;
        using UnifiedBusinessObject::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<MeetingReminderInfoObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<MeetingReminderInfoObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<MeetingReminderInfoNotifiers> getMeetingReminderInfoNotifiers() = 0;

        
    
        virtual MeetingReminderTypeEnum::MeetingReminderType getReminderType() = 0;
        virtual std::string getReminderSender() = 0;
        virtual std::string getMeetingID() = 0;
        virtual std::string getMeetingTopic() = 0;
        virtual std::string getLocation() = 0;
        virtual std::string getHostEmail() = 0;
        virtual std::string getHostDisplayName() = 0;
        virtual bool getIsHost() = 0;
        virtual SMART_PTR_NS::shared_ptr<MeetingTime> getStartTime() = 0;
        virtual SMART_PTR_NS::shared_ptr<MeetingTime> getEndTime() = 0;
        virtual long getDuration() = 0;
        virtual std::string getSiteUrl() = 0;
        virtual std::string getMeetingKey() = 0;
        virtual std::string getJoinUrl() = 0;
	


        

/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingReminderInfo";
        }

    };
    
}

#endif