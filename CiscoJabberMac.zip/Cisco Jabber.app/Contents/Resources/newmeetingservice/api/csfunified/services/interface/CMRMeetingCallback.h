/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/

#ifndef CMRMEETINGCALLBACK_H
#define CMRMEETINGCALLBACK_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedCallback.h"
#include "csfunified/services/interface/CMRMeetingErrorCode.h"

namespace CSFUnified 
{

    class CMRController;

    class CSFUNIFIED_API CMRMeetingCallback : public UnifiedCallback
    {
        public:

        

        
    
        virtual void onMeetingStarted(CMRMeetingErrorCodeEnum::CMRMeetingErrorCode errCode, SMART_PTR_NS::shared_ptr<CMRController> cmrContrller) = 0;
        virtual void onMeetingJoined(CMRMeetingErrorCodeEnum::CMRMeetingErrorCode errCode, SMART_PTR_NS::shared_ptr<CMRController> cmrContrller) = 0;
        virtual void onMeetingEnded(SMART_PTR_NS::shared_ptr<CMRController> cmrContrller) = 0;



        /**    
	 Gives the name of this business object for logging and wrapping purposes    
		*/
        virtual std::string getInterfaceName()
        {
            return "CMRMeetingCallback";
        }
    };

}

#endif