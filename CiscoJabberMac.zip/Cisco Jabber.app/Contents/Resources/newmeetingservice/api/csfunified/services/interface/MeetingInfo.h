/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGINFO_H
#define MEETINGINFO_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedBusinessObject.h"
#include "csfunified/services/interface/MeetingType.h"
#include "csfunified/services/interface/WebexServiceType.h"

namespace CSFUnified
{
    class MeetingTime;
    class MeetingAttendee;
    class MeetingCallInNum;

/**
    @class MeetingInfoObserver
    This interface when implemented allows you to act as an observer for the MeetingInfo class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API MeetingInfoObserver : virtual public UnifiedBusinessObjectObserver
    {
        public:
        

        
    
        virtual void OnMeetingEventXMLChanged() = 0;
        virtual void OnMeetingDetailXMLChanged() = 0;
        virtual void OnMeetingIDChanged() = 0;
        virtual void OnMeetingTopicChanged() = 0;
        virtual void OnHostIDChanged() = 0;
        virtual void OnHostEmailChanged() = 0;
        virtual void OnIsHostChanged() = 0;
        virtual void OnIsRecurrenceChanged() = 0;
        virtual void OnMeetingTypeChanged() = 0;
        virtual void OnStartTimeChanged() = 0;
        virtual void OnDurationChanged() = 0;
        virtual void OnAttendeesChanged(SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingAttendee> > > added, SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingAttendee> > > removed) = 0;
        virtual void OnLocationChanged() = 0;
        virtual void OnSiteUrlChanged() = 0;
        virtual void OnMeetingKeyChanged() = 0;
        virtual void OnIsAudioOnlyChanged() = 0;
        virtual void OnIsInProgressChanged() = 0;
        virtual void OnWbxServiceTypeChanged() = 0;
        virtual void OnJoinUrlChanged() = 0;
        virtual void OnTeleDescChanged() = 0;
        virtual void OnTeleSupportChanged() = 0;
        virtual void OnTeleFreeResUrlChanged() = 0;
        virtual void OnGlobalCallinUrlChanged() = 0;
        virtual void OnCallInNumsChanged(SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingCallInNum> > > added, SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingCallInNum> > > removed) = 0;
	


/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingInfoObserver";
        }

    };
/**
    @class MeetingInfoNotifiers
    This class gives you access to a single notifer object for each property on the MeetingInfo class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the MeetingInfoObserver class
*/

    class CSFUNIFIED_API MeetingInfoNotifiers : virtual public UnifiedBusinessObjectNotifiers
    {
        public:

        

         
    
    /**    
        Returns the notifier for the MeetingEventXML property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingEventXMLNotifier() =0;
    /**    
        Returns the notifier for the MeetingDetailXML property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingDetailXMLNotifier() =0;
    /**    
        Returns the notifier for the MeetingID property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingIDNotifier() =0;
    /**    
        Returns the notifier for the MeetingTopic property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingTopicNotifier() =0;
    /**    
        Returns the notifier for the HostID property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getHostIDNotifier() =0;
    /**    
        Returns the notifier for the HostEmail property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getHostEmailNotifier() =0;
    /**    
        Returns the notifier for the IsHost property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getIsHostNotifier() =0;
    /**    
        Returns the notifier for the IsRecurrence property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getIsRecurrenceNotifier() =0;
    /**    
        Returns the notifier for the MeetingType property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingTypeNotifier() =0;
    /**    
        Returns the notifier for the StartTime property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getStartTimeNotifier() =0;
    /**    
        Returns the notifier for the Duration property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getDurationNotifier() =0;
    /**    
        Returns the notifier for the Attendees property
    */
	    virtual SMART_PTR_NS::shared_ptr<PropertyListNotifier<MeetingAttendee> > getAttendeesNotifier() =0;
    /**    
        Returns the notifier for the Location property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getLocationNotifier() =0;
    /**    
        Returns the notifier for the SiteUrl property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getSiteUrlNotifier() =0;
    /**    
        Returns the notifier for the MeetingKey property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingKeyNotifier() =0;
    /**    
        Returns the notifier for the IsAudioOnly property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getIsAudioOnlyNotifier() =0;
    /**    
        Returns the notifier for the IsInProgress property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getIsInProgressNotifier() =0;
    /**    
        Returns the notifier for the WbxServiceType property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getWbxServiceTypeNotifier() =0;
    /**    
        Returns the notifier for the JoinUrl property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getJoinUrlNotifier() =0;
    /**    
        Returns the notifier for the TeleDesc property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getTeleDescNotifier() =0;
    /**    
        Returns the notifier for the TeleSupport property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getTeleSupportNotifier() =0;
    /**    
        Returns the notifier for the TeleFreeResUrl property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getTeleFreeResUrlNotifier() =0;
    /**    
        Returns the notifier for the GlobalCallinUrl property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getGlobalCallinUrlNotifier() =0;
    /**    
        Returns the notifier for the CallInNums property
    */
	    virtual SMART_PTR_NS::shared_ptr<PropertyListNotifier<MeetingCallInNum> > getCallInNumsNotifier() =0;
	

    };
    

	class CSFUNIFIED_API MeetingInfo : virtual public UnifiedBusinessObject
    {
        public:

        


        using UnifiedBusinessObject::addObserver;
        using UnifiedBusinessObject::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<MeetingInfoObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<MeetingInfoObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<MeetingInfoNotifiers> getMeetingInfoNotifiers() = 0;

        
    
        virtual std::string getMeetingEventXML() = 0;
        virtual std::string getMeetingDetailXML() = 0;
        virtual std::string getMeetingID() = 0;
        virtual std::string getMeetingTopic() = 0;
        virtual std::string getHostID() = 0;
        virtual std::string getHostEmail() = 0;
        virtual bool getIsHost() = 0;
        virtual bool getIsRecurrence() = 0;
        virtual MeetingTypeEnum::MeetingType getMeetingType() = 0;
        virtual SMART_PTR_NS::shared_ptr<MeetingTime> getStartTime() = 0;
        virtual long getDuration() = 0;
        virtual SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingAttendee> > > getAttendees() = 0;
        virtual std::string getLocation() = 0;
        virtual std::string getSiteUrl() = 0;
        virtual std::string getMeetingKey() = 0;
        virtual bool getIsAudioOnly() = 0;
        virtual bool getIsInProgress() = 0;
        virtual WebexServiceTypeEnum::WebexServiceType getWbxServiceType() = 0;
        virtual std::string getJoinUrl() = 0;
        virtual std::string getTeleDesc() = 0;
        virtual std::string getTeleSupport() = 0;
        virtual std::string getTeleFreeResUrl() = 0;
        virtual std::string getGlobalCallinUrl() = 0;
        virtual SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingCallInNum> > > getCallInNums() = 0;
	


        

/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingInfo";
        }

    };
    
}

#endif