/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETING_H
#define MEETING_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedBusinessObject.h"

namespace CSFUnified
{
    class MeetingParticipant;

/**
    @class MeetingObserver
    This interface when implemented allows you to act as an observer for the Meeting class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API MeetingObserver : virtual public UnifiedBusinessObjectObserver
    {
        public:
        

        
    
        virtual void OnNameChanged() = 0;
        virtual void OnParticipantsChanged(SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingParticipant> > > added, SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingParticipant> > > removed) = 0;
	


/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingObserver";
        }

    };
/**
    @class MeetingNotifiers
    This class gives you access to a single notifer object for each property on the Meeting class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the MeetingObserver class
*/

    class CSFUNIFIED_API MeetingNotifiers : virtual public UnifiedBusinessObjectNotifiers
    {
        public:

        

         
    
    /**    
        Returns the notifier for the Name property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getNameNotifier() =0;
    /**    
        Returns the notifier for the Participants property
    */
	    virtual SMART_PTR_NS::shared_ptr<PropertyListNotifier<MeetingParticipant> > getParticipantsNotifier() =0;
	

    };
    

	class CSFUNIFIED_API Meeting : virtual public UnifiedBusinessObject
    {
        public:

        


        using UnifiedBusinessObject::addObserver;
        using UnifiedBusinessObject::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<MeetingObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<MeetingObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<MeetingNotifiers> getMeetingNotifiers() = 0;

        
    
        virtual std::string getName() = 0;
        virtual SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<MeetingParticipant> > > getParticipants() = 0;
	


        

/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "Meeting";
        }

    };
    
}

#endif