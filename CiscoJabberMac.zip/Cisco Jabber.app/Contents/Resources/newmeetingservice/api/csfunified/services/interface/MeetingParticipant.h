/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGPARTICIPANT_H
#define MEETINGPARTICIPANT_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedBusinessObject.h"

namespace CSFUnified
{

/**
    @class MeetingParticipantObserver
    This interface when implemented allows you to act as an observer for the MeetingParticipant class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API MeetingParticipantObserver : virtual public UnifiedBusinessObjectObserver
    {
        public:
        

        
    
        virtual void OnNameChanged() = 0;
	


/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingParticipantObserver";
        }

    };
/**
    @class MeetingParticipantNotifiers
    This class gives you access to a single notifer object for each property on the MeetingParticipant class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the MeetingParticipantObserver class
*/

    class CSFUNIFIED_API MeetingParticipantNotifiers : virtual public UnifiedBusinessObjectNotifiers
    {
        public:

        

         
    
    /**    
        Returns the notifier for the Name property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getNameNotifier() =0;
	

    };
    

	class CSFUNIFIED_API MeetingParticipant : virtual public UnifiedBusinessObject
    {
        public:

        


        using UnifiedBusinessObject::addObserver;
        using UnifiedBusinessObject::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<MeetingParticipantObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<MeetingParticipantObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<MeetingParticipantNotifiers> getMeetingParticipantNotifiers() = 0;

        
    
        virtual std::string getName() = 0;
	


        

/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingParticipant";
        }

    };
    
}

#endif