/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGIMALERTITEMOBJECT_H
#define MEETINGIMALERTITEMOBJECT_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedBusinessObject.h"

namespace CSFUnified
{

/**
    @class MeetingIMAlertItemObjectObserver
    This interface when implemented allows you to act as an observer for the MeetingIMAlertItemObject class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API MeetingIMAlertItemObjectObserver : virtual public UnifiedBusinessObjectObserver
    {
        public:
        

        
    
        virtual void OnstrMeetingKeyChanged() = 0;
        virtual void OnstrMeetingTitleChanged() = 0;
        virtual void OnstrHostEmailChanged() = 0;
        virtual void OnstrHostDisplayNameChanged() = 0;
        virtual void OnstrDetailMeetingInfoChanged() = 0;
        virtual void OnstrAttendeeInfoChanged() = 0;
        virtual void OnstrJoinURLChanged() = 0;
        virtual void OnstrSiteURLChanged() = 0;
	


/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingIMAlertItemObjectObserver";
        }

    };
/**
    @class MeetingIMAlertItemObjectNotifiers
    This class gives you access to a single notifer object for each property on the MeetingIMAlertItemObject class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the MeetingIMAlertItemObjectObserver class
*/

    class CSFUNIFIED_API MeetingIMAlertItemObjectNotifiers : virtual public UnifiedBusinessObjectNotifiers
    {
        public:

        

         
    
    /**    
        Returns the notifier for the strMeetingKey property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getstrMeetingKeyNotifier() =0;
    /**    
        Returns the notifier for the strMeetingTitle property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getstrMeetingTitleNotifier() =0;
    /**    
        Returns the notifier for the strHostEmail property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getstrHostEmailNotifier() =0;
    /**    
        Returns the notifier for the strHostDisplayName property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getstrHostDisplayNameNotifier() =0;
    /**    
        Returns the notifier for the strDetailMeetingInfo property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getstrDetailMeetingInfoNotifier() =0;
    /**    
        Returns the notifier for the strAttendeeInfo property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getstrAttendeeInfoNotifier() =0;
    /**    
        Returns the notifier for the strJoinURL property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getstrJoinURLNotifier() =0;
    /**    
        Returns the notifier for the strSiteURL property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getstrSiteURLNotifier() =0;
	

    };
    

	class CSFUNIFIED_API MeetingIMAlertItemObject : virtual public UnifiedBusinessObject
    {
        public:

        


        using UnifiedBusinessObject::addObserver;
        using UnifiedBusinessObject::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<MeetingIMAlertItemObjectObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<MeetingIMAlertItemObjectObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<MeetingIMAlertItemObjectNotifiers> getMeetingIMAlertItemObjectNotifiers() = 0;

        
    
        virtual std::string getstrMeetingKey() = 0;
        virtual std::string getstrMeetingTitle() = 0;
        virtual std::string getstrHostEmail() = 0;
        virtual std::string getstrHostDisplayName() = 0;
        virtual std::string getstrDetailMeetingInfo() = 0;
        virtual std::string getstrAttendeeInfo() = 0;
        virtual std::string getstrJoinURL() = 0;
        virtual std::string getstrSiteURL() = 0;
	


        

/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingIMAlertItemObject";
        }

    };
    
}

#endif