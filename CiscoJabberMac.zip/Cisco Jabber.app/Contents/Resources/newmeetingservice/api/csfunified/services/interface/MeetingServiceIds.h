/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGSERVICEIDS_H
#define MEETINGSERVICEIDS_H

#include <string>
#include <vector>
#include "csfunified/library/CSFUnified.h"


 #include "MeetingServiceIds_enum.h"

namespace CSFUnified
{
    namespace MeetingServiceIdsEnum
    {

       
        #ifndef SWIG
        inline std::string toString(MeetingServiceIds value)
        {
            switch(value)
            {
                case MeetingService:
                    return "MeetingService";
                default:
                    return "";
            }
        }
		
		inline std::wstring toWideString(MeetingServiceIds value)
        {
            switch(value)
            {
                case MeetingService:
                    return L"MeetingService";
                default:
                    return L"";
            }
        }
		
		typedef const std::vector<MeetingServiceIds> MeetingServiceIdsEnumerator;
		typedef SMART_PTR_NS::shared_ptr<const std::vector<MeetingServiceIds> > MeetingServiceIdsEnumeratorPtr;
		
		inline MeetingServiceIdsEnumeratorPtr Enumerator()
        {
			static SMART_PTR_NS::shared_ptr<std::vector<MeetingServiceIds> > vec( new std::vector<MeetingServiceIds>());
			
			if (vec->empty())
			{
                vec->push_back( MeetingService );
            }
			
			return vec;
        }
		#endif
    }
}
#endif