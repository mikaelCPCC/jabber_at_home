/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGSERVICEFEATURESETTYPES_ENUM_H
#define MEETINGSERVICEFEATURESETTYPES_ENUM_H


namespace CSFUnified
{
    namespace MeetingServiceFeatureSetTypesEnum
    {
        enum MeetingServiceFeatureSetTypes {
        Meeting = 3000 
        };
    }
}
#endif