/******************************************************************************
*  Do not modify this file!
*  This file is auto-generated.
*  Any changes will be lost.
*  This interface is defined in model.xml
******************************************************************************/
#ifndef MEETINGSERVICE_H
#define MEETINGSERVICE_H

#include <string>
#include "csfunified/library/CSFUnified.h"
#include "csfunified/services/interface/UnifiedService.h"
#include "csfunified/services/interface/CalendarType.h"
#include "csfunified/services/interface/MailServiceType.h"

namespace CSFUnified
{
    class Meeting;
    class CMRMeetingCallback;
    class MeetingMgrController;
    class DesktopSharingController;
    class MeetingAccountController;
    class CMRController;

/**
    @class MeetingServiceObserver
    This interface when implemented allows you to act as an observer for the MeetingService class via its addObserver Method
    and receive notifications of property changes. Alternatively you use the property notifier mechanism instead and
    listen to events on a single property individually.
*/

    class CSFUNIFIED_API MeetingServiceObserver : virtual public UnifiedServiceObserver
    {
        public:
        

        
    
        virtual void OnMeetingsChanged(SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<Meeting> > > added, SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<Meeting> > > removed) = 0;
        virtual void OnMeetingContentChanged() = 0;
        virtual void OnIntegrationCalendarTypeChanged() = 0;
        virtual void OnIsCMREnabledChanged() = 0;
	


/**    
    Gives the name of this observer for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingServiceObserver";
        }

    };
/**
    @class MeetingServiceNotifiers
    This class gives you access to a single notifer object for each property on the MeetingService class.
    With these you may listen to individual property changes. Alternatively you may use the observer pattern
    via the MeetingServiceObserver class
*/

    class CSFUNIFIED_API MeetingServiceNotifiers : virtual public UnifiedServiceNotifiers
    {
        public:

        

         
    
    /**    
        Returns the notifier for the Meetings property
    */
	    virtual SMART_PTR_NS::shared_ptr<PropertyListNotifier<Meeting> > getMeetingsNotifier() =0;
    /**    
        Returns the notifier for the MeetingContent property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getMeetingContentNotifier() =0;
    /**    
        Returns the notifier for the IntegrationCalendarType property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getIntegrationCalendarTypeNotifier() =0;
    /**    
        Returns the notifier for the IsCMREnabled property
    */
        virtual SMART_PTR_NS::shared_ptr<PropertyNotifier> getIsCMREnabledNotifier() =0;
	

    };
    

	class CSFUNIFIED_API MeetingService : virtual public UnifiedService
    {
        public:

        


        using UnifiedService::addObserver;
        using UnifiedService::removeObserver;

/**    
    Adds an observer to this class who will be notified when property changes occur    
*/
        virtual void addObserver(SMART_PTR_NS::weak_ptr<MeetingServiceObserver> observer) =0;
/**    
    Removes an observer and stops property change notification from being issued to them   
*/
        virtual void removeObserver(SMART_PTR_NS::weak_ptr<MeetingServiceObserver> observer) =0;
 
/**    
    Gets the notifiers object for this class which allows access to a property change notifier for each property on the class.
*/       
        virtual SMART_PTR_NS::shared_ptr<MeetingServiceNotifiers> getMeetingServiceNotifiers() = 0;

        
    
        virtual SMART_PTR_NS::shared_ptr<std::vector<SMART_PTR_NS::shared_ptr<Meeting> > > getMeetings() = 0;
        virtual std::string getMeetingContent() = 0;
        virtual CalendarTypeEnum::CalendarType getIntegrationCalendarType() = 0;
        virtual void setIntegrationCalendarType(CalendarTypeEnum::CalendarType update) = 0;
        virtual bool getIsCMREnabled() = 0;
	


        
    
        virtual bool isMeetingModuleEnabled() = 0;
        virtual bool isDesktopShareModuleEnable() = 0;
        virtual MailServiceTypeEnum::MailServiceType getDefaultMailClient() = 0;


    
        virtual SMART_PTR_NS::shared_ptr<MeetingMgrController> getMeetingMgrController() = 0;
        virtual SMART_PTR_NS::shared_ptr<DesktopSharingController> getDesktopSharingController() = 0;
        virtual SMART_PTR_NS::shared_ptr<MeetingAccountController> getMeetingAccountController() = 0;
        virtual SMART_PTR_NS::shared_ptr<CMRController> getCMRController(std::string JID) = 0;
        virtual void registerCMRMeetingCallback(SMART_PTR_NS::shared_ptr<CMRMeetingCallback> callback) = 0;
        virtual void unregisterCMRMeetingCallback(SMART_PTR_NS::shared_ptr<CMRMeetingCallback> callback) = 0;
        virtual void loggedIn() = 0;
        virtual void loggedOut() = 0;



/**    
    Gives the name of this business object for logging and wrapping purposes    
*/
        virtual std::string getInterfaceName()
        {
            return "MeetingService";
        }

    };
    
}

#endif