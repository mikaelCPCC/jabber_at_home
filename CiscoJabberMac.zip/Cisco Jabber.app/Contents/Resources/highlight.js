var searchKeywords;

function highlightAllOccurencesOfStringInBody(keyword) {
	searchKeywords = keyword.split(" ");

	$("body").unhighlight();
	$("body").highlight(searchKeywords);
	$(".highlight").css({ backgroundColor: "#FFFF88" });
}

function clearHighlights() {
	$("body").unhighlight();
}

$(document).ready(function() {
	highlightAllOccurencesOfStringInBody(searchKeywords);
});